import{s as t}from"../chunks/vendor.Cw1YmV38.js";export{t as start};
