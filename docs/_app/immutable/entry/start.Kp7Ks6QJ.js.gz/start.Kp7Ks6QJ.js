import{s as t}from"../chunks/vendor.Ytfcq54i.js";export{t as start};
