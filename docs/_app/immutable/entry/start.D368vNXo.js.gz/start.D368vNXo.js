import{s as t}from"../chunks/vendor.Zc7J5MNC.js";export{t as start};
