import{s as t}from"../chunks/vendor.C3g9NrnR.js";export{t as start};
