import{s as t}from"../chunks/vendor.Dbe460yO.js";export{t as start};
