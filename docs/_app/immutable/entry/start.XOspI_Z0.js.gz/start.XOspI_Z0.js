import{s as t}from"../chunks/vendor._g0e3dLr.js";export{t as start};
