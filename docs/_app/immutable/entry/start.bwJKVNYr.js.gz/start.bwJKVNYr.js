import{s as t}from"../chunks/vendor.CvQ1hacC.js";export{t as start};
