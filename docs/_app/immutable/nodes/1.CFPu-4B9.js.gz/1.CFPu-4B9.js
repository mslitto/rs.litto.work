import{E as m}from"../chunks/vendor.Dhg3Zp6M.js";export{m as component};
