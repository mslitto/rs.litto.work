import{E as m}from"../chunks/vendor.BD790YXE.js";export{m as component};
